"""
Менеджер заметок (NoteManager) для Notebook Organizer.

NoteManager является центральным компонентом приложения:
он объединяет CRUD-операции, стек отмены, фильтрацию и хранилище.
"""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime, date
from typing import Any

from .filters import NoteFilter
from .models import Note, TextNote, VoiceNote, ChecklistNote, note_from_dict
from .storage import JSONStorage, StorageError
from .undo_stack import UndoStack, AddNoteCommand, DeleteNoteCommand, UpdateNoteCommand
from .validators import NoteValidator


class NoteNotFoundError(Exception):
    """Заметка с указанным ID не найдена."""


class NoteManager:
    """Менеджер заметок — центральный фасад для работы с коллекцией заметок.

    Поддерживает:
    - CRUD-операции (Create, Read, Update, Delete)
    - Стек отмены (UndoStack)
    - Фильтрацию и сортировку
    - Сохранение/загрузку через JSONStorage
    """

    def __init__(
        self,
        storage: JSONStorage | None = None,
        undo_stack: UndoStack | None = None,
    ) -> None:
        self._notes: list[Note] = []
        self._storage: JSONStorage = storage or JSONStorage()
        self._undo: UndoStack = undo_stack or UndoStack()

    # ==================================================================
    # CREATE
    # ==================================================================

    def add_note(self, note: Note) -> Note:
        """Добавляет заметку в коллекцию и записывает команду в стек.

        Args:
            note: Объект заметки (TextNote, VoiceNote или ChecklistNote).

        Returns:
            Добавленная заметка.

        Raises:
            ValueError: Если заметка с таким ID уже существует.
        """
        if self._find_index(note.note_id) is not None:
            raise ValueError(f"Заметка с ID '{note.note_id}' уже существует.")
        cmd = AddNoteCommand(self._notes, note)
        cmd.execute()
        self._undo.push(cmd)
        return self._notes[-1]

    def create_text_note(
        self,
        title: str,
        text: str = "",
        tags: list[str] | None = None,
    ) -> TextNote:
        """Создаёт и добавляет текстовую заметку."""
        title = NoteValidator.validate_title(title)
        text = NoteValidator.validate_text(text, field_name="Текст")
        tags = NoteValidator.validate_tags(tags or [])
        note = TextNote(title=title, text=text, tags=tags)
        return self.add_note(note)  # type: ignore[return-value]

    def create_voice_note(
        self,
        title: str,
        transcription: str = "",
        duration_sec: int = 0,
        tags: list[str] | None = None,
    ) -> VoiceNote:
        """Создаёт и добавляет голосовую заметку."""
        title = NoteValidator.validate_title(title)
        transcription = NoteValidator.validate_text(
            transcription, field_name="Транскрипция"
        )
        duration_sec = NoteValidator.validate_duration(duration_sec)
        tags = NoteValidator.validate_tags(tags or [])
        note = VoiceNote(
            title=title,
            transcription=transcription,
            duration_sec=duration_sec,
            tags=tags,
        )
        return self.add_note(note)  # type: ignore[return-value]

    def create_checklist_note(
        self,
        title: str,
        items: list[dict] | None = None,
        tags: list[str] | None = None,
    ) -> ChecklistNote:
        """Создаёт и добавляет заметку-чеклист."""
        title = NoteValidator.validate_title(title)
        items = NoteValidator.validate_checklist_items(items or [])
        tags = NoteValidator.validate_tags(tags or [])
        note = ChecklistNote(title=title, items=items, tags=tags)
        return self.add_note(note)  # type: ignore[return-value]

    # ==================================================================
    # READ
    # ==================================================================

    def get_all(self) -> list[Note]:
        """Возвращает копию всех заметок."""
        return list(self._notes)

    def get_by_id(self, note_id: str) -> Note:
        """Возвращает заметку по идентификатору.

        Raises:
            NoteNotFoundError: Если заметка не найдена.
        """
        idx = self._find_index(note_id)
        if idx is None:
            raise NoteNotFoundError(f"Заметка с ID '{note_id}' не найдена.")
        return deepcopy(self._notes[idx])

    def count(self) -> int:
        """Возвращает общее количество заметок."""
        return len(self._notes)

    # ==================================================================
    # UPDATE
    # ==================================================================

    def update_note(self, note_id: str, **kwargs: Any) -> Note:
        """Обновляет поля заметки по идентификатору.

        Поддерживаемые поля зависят от типа заметки:
        - Все типы: title, tags
        - TextNote: text
        - VoiceNote: transcription, duration_sec
        - ChecklistNote: items

        Args:
            note_id: Идентификатор заметки.
            **kwargs: Поля для обновления.

        Returns:
            Обновлённая заметка.

        Raises:
            NoteNotFoundError: Если заметка не найдена.
            ValueError: При некорректных данных.
        """
        idx = self._find_index(note_id)
        if idx is None:
            raise NoteNotFoundError(f"Заметка с ID '{note_id}' не найдена.")

        old_note = deepcopy(self._notes[idx])
        new_note = deepcopy(self._notes[idx])

        if "title" in kwargs:
            new_note.title = NoteValidator.validate_title(kwargs["title"])
        if "tags" in kwargs:
            new_note.tags = NoteValidator.validate_tags(kwargs["tags"])

        if isinstance(new_note, TextNote):
            if "text" in kwargs:
                new_note.text = NoteValidator.validate_text(
                    kwargs["text"], field_name="Текст"
                )
        elif isinstance(new_note, VoiceNote):
            if "transcription" in kwargs:
                new_note.transcription = NoteValidator.validate_text(
                    kwargs["transcription"], field_name="Транскрипция"
                )
            if "duration_sec" in kwargs:
                new_note.duration_sec = NoteValidator.validate_duration(
                    kwargs["duration_sec"]
                )
        elif isinstance(new_note, ChecklistNote):
            if "items" in kwargs:
                new_note.items = NoteValidator.validate_checklist_items(kwargs["items"])

        new_note.update_date()

        cmd = UpdateNoteCommand(self._notes, old_note, new_note)
        cmd.execute()
        self._undo.push(cmd)
        return deepcopy(self._notes[idx])

    # ==================================================================
    # DELETE
    # ==================================================================

    def delete_note(self, note_id: str) -> Note:
        """Удаляет заметку по идентификатору.

        Returns:
            Удалённая заметка.

        Raises:
            NoteNotFoundError: Если заметка не найдена.
        """
        idx = self._find_index(note_id)
        if idx is None:
            raise NoteNotFoundError(f"Заметка с ID '{note_id}' не найдена.")
        note = deepcopy(self._notes[idx])
        cmd = DeleteNoteCommand(self._notes, note)
        cmd.execute()
        self._undo.push(cmd)
        return note

    def delete_all(self) -> int:
        """Удаляет все заметки. Возвращает количество удалённых заметок."""
        count = len(self._notes)
        self._notes.clear()
        self._undo.clear()
        return count

    # ==================================================================
    # UNDO
    # ==================================================================

    def undo(self) -> str:
        """Отменяет последнее действие.

        Returns:
            Описание отменённой операции.

        Raises:
            IndexError: Если история пуста.
        """
        return self._undo.undo()

    def undo_history(self) -> list[str]:
        """Возвращает список описаний действий в истории."""
        return self._undo.history()

    @property
    def can_undo(self) -> bool:
        """True, если есть что отменять."""
        return not self._undo.is_empty

    # ==================================================================
    # ФИЛЬТРАЦИЯ
    # ==================================================================

    def filter_by_tag(self, tag: str) -> list[Note]:
        """Возвращает заметки с указанным тегом."""
        return NoteFilter.by_tag(self._notes, tag)

    def filter_by_tags_all(self, tags: list[str]) -> list[Note]:
        """Возвращает заметки, содержащие все указанные теги."""
        return NoteFilter.by_tags_all(self._notes, tags)

    def filter_by_tags_any(self, tags: list[str]) -> list[Note]:
        """Возвращает заметки, содержащие хотя бы один из тегов."""
        return NoteFilter.by_tags_any(self._notes, tags)

    def filter_by_date(self, target_date: date) -> list[Note]:
        """Возвращает заметки за указанный день."""
        return NoteFilter.by_date(self._notes, target_date)

    def filter_by_date_range(
        self,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> list[Note]:
        """Возвращает заметки в диапазоне дат."""
        return NoteFilter.by_date_range(self._notes, start, end)

    def filter_by_type(self, note_type: str) -> list[Note]:
        """Возвращает заметки указанного типа."""
        return NoteFilter.by_type(self._notes, note_type)

    def search_by_title(self, query: str) -> list[Note]:
        """Возвращает заметки, заголовок которых содержит строку запроса."""
        return NoteFilter.by_title(self._notes, query)

    def sorted_by_date(self, descending: bool = True) -> list[Note]:
        """Возвращает заметки, отсортированные по дате."""
        return NoteFilter.sort_by_date(self._notes, descending)

    def sorted_by_title(self, descending: bool = False) -> list[Note]:
        """Возвращает заметки, отсортированные по заголовку."""
        return NoteFilter.sort_by_title(self._notes, descending)

    # ==================================================================
    # ХРАНИЛИЩЕ
    # ==================================================================

    def save(self) -> None:
        """Сохраняет все заметки в JSON-файл."""
        self._storage.save(self._notes)

    def load(self) -> int:
        """Загружает заметки из JSON-файла.

        Returns:
            Количество загруженных заметок.

        Raises:
            StorageError: При ошибке чтения файла.
        """
        self._notes = self._storage.load()
        self._undo.clear()
        return len(self._notes)

    @property
    def storage_path(self) -> str:
        """Путь к файлу хранилища."""
        return str(self._storage.path)

    # ==================================================================
    # Вспомогательные методы
    # ==================================================================

    def _find_index(self, note_id: str) -> int | None:
        """Возвращает индекс заметки по ID или None."""
        for i, note in enumerate(self._notes):
            if note.note_id == note_id:
                return i
        return None

    def __len__(self) -> int:
        return len(self._notes)

    def __repr__(self) -> str:
        return f"NoteManager(count={len(self._notes)}, storage={self._storage.path!r})"
