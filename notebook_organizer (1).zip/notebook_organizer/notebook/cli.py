"""
Консольный интерфейс (CLI) для Notebook Organizer.

Предоставляет интерактивное меню для управления заметками:
создание, просмотр, редактирование, удаление, фильтрация и отмена действий.
"""

from __future__ import annotations

import os
import sys
from datetime import datetime
from textwrap import fill, indent
from typing import Callable

from .manager import NoteManager, NoteNotFoundError
from .models import Note, TextNote, VoiceNote, ChecklistNote
from .storage import StorageError


# ---------------------------------------------------------------------------
# Цветовые коды ANSI (отключаются при перенаправлении вывода)
# ---------------------------------------------------------------------------

USE_COLOR: bool = sys.stdout.isatty()


def _c(code: str, text: str) -> str:
    """Оборачивает текст в ANSI-код цвета (если терминал поддерживает)."""
    if not USE_COLOR:
        return text
    return f"\033[{code}m{text}\033[0m"


def bold(text: str) -> str:
    return _c("1", text)


def green(text: str) -> str:
    return _c("32", text)


def red(text: str) -> str:
    return _c("31", text)


def yellow(text: str) -> str:
    return _c("33", text)


def cyan(text: str) -> str:
    return _c("36", text)


def dim(text: str) -> str:
    return _c("2", text)


# ---------------------------------------------------------------------------
# Вспомогательные функции ввода/вывода
# ---------------------------------------------------------------------------

SEPARATOR = "─" * 60


def print_separator() -> None:
    print(dim(SEPARATOR))


def print_header(title: str) -> None:
    print()
    print(bold(cyan(f"  {title}")))
    print_separator()


def print_success(msg: str) -> None:
    print(green(f"  ✓ {msg}"))


def print_error(msg: str) -> None:
    print(red(f"  ✗ {msg}"))


def print_warning(msg: str) -> None:
    print(yellow(f"  ! {msg}"))


def print_info(msg: str) -> None:
    print(f"  {msg}")


def ask(prompt: str, default: str = "") -> str:
    """Запрашивает строку у пользователя."""
    if default:
        prompt = f"{prompt} [{default}]: "
    else:
        prompt = f"{prompt}: "
    try:
        value = input(f"  {prompt}").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return default
    return value if value else default


def ask_multiline(prompt: str) -> str:
    """Запрашивает многострочный текст (завершение — пустая строка)."""
    print(f"  {prompt} (пустая строка для завершения):")
    lines: list[str] = []
    while True:
        try:
            line = input("  > ")
        except (EOFError, KeyboardInterrupt):
            break
        if line == "":
            break
        lines.append(line)
    return "\n".join(lines)


def ask_tags(prompt: str = "Теги") -> list[str]:
    """Запрашивает теги через запятую."""
    raw = ask(f"{prompt} (через запятую, Enter — пропустить)")
    if not raw:
        return []
    return [t.strip() for t in raw.split(",") if t.strip()]


def confirm(prompt: str) -> bool:
    """Запрашивает подтверждение (y/n)."""
    answer = ask(f"{prompt} [y/N]").lower()
    return answer in ("y", "yes", "д", "да")


def paginate(items: list, page_size: int = 10) -> None:
    """Выводит список с постраничной навигацией."""
    if not items:
        print_warning("Список пуст.")
        return
    total = len(items)
    start = 0
    while start < total:
        end = min(start + page_size, total)
        for item in items[start:end]:
            print(item)
        start = end
        if start < total:
            cont = ask(f"\n  Показано {start}/{total}. Продолжить? [Y/n]").lower()
            if cont in ("n", "no", "н", "нет"):
                break


# ---------------------------------------------------------------------------
# Форматирование заметок
# ---------------------------------------------------------------------------

TYPE_LABELS = {
    "text": "Текст",
    "voice": "Голос",
    "checklist": "Чеклист",
}

TYPE_COLORS = {
    "text": cyan,
    "voice": yellow,
    "checklist": green,
}


def format_note_short(note: Note, index: int | None = None) -> str:
    """Форматирует краткое представление заметки для списка."""
    type_label = TYPE_LABELS.get(note.note_type, note.note_type)
    color_fn = TYPE_COLORS.get(note.note_type, lambda x: x)
    idx_str = f"{index:>3}. " if index is not None else "     "
    tags_str = " ".join(f"#{t}" for t in note.tags) if note.tags else dim("(нет тегов)")
    date_str = note.date.strftime("%d.%m.%Y %H:%M")
    preview = note.preview() or dim("(пусто)")
    lines = [
        f"{idx_str}{bold(note.title)}  {color_fn(f'[{type_label}]')}",
        f"       {dim(date_str)}  {dim(tags_str)}",
        f"       {preview}",
        f"       {dim('ID: ' + note.note_id[:8] + '…')}",
    ]
    return "\n".join(lines)


def format_note_full(note: Note) -> str:
    """Форматирует полное представление заметки."""
    type_label = TYPE_LABELS.get(note.note_type, note.note_type)
    color_fn = TYPE_COLORS.get(note.note_type, lambda x: x)
    tags_str = " ".join(f"#{t}" for t in note.tags) if note.tags else dim("(нет тегов)")
    date_str = note.date.strftime("%d.%m.%Y %H:%M:%S")

    lines = [
        f"  {bold('Заголовок:')} {note.title}",
        f"  {bold('Тип:')}      {color_fn(type_label)}",
        f"  {bold('Дата:')}     {date_str}",
        f"  {bold('Теги:')}     {tags_str}",
        f"  {bold('ID:')}       {note.note_id}",
        "",
    ]

    if isinstance(note, TextNote):
        lines.append(f"  {bold('Текст:')}")
        if note.text:
            for line in note.text.splitlines():
                lines.append(f"    {line}")
        else:
            lines.append(f"    {dim('(пусто)')}")

    elif isinstance(note, VoiceNote):
        mins, secs = divmod(note.duration_sec, 60)
        lines.append(f"  {bold('Длительность:')} {mins:02d}:{secs:02d}")
        lines.append(f"  {bold('Транскрипция:')}")
        if note.transcription:
            for line in note.transcription.splitlines():
                lines.append(f"    {line}")
        else:
            lines.append(f"    {dim('(пусто)')}")

    elif isinstance(note, ChecklistNote):
        total = len(note.items)
        done = sum(1 for i in note.items if i["done"])
        lines.append(f"  {bold('Пункты:')} {done}/{total} выполнено")
        for idx, item in enumerate(note.items):
            mark = green("✓") if item["done"] else dim("○")
            lines.append(f"    {idx + 1:>2}. {mark} {item['text']}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Главное меню
# ---------------------------------------------------------------------------

MAIN_MENU = """
  {bold_title}

  {sep}
  {n1}  Список заметок
  {n2}  Создать заметку
  {n3}  Просмотреть заметку
  {n4}  Редактировать заметку
  {n5}  Удалить заметку
  {sep}
  {f1}  Фильтр по тегу
  {f2}  Фильтр по дате
  {f3}  Фильтр по типу
  {f4}  Поиск по заголовку
  {sep}
  {u1}  Отменить последнее действие
  {u2}  История действий
  {sep}
  {s1}  Сохранить заметки
  {s2}  Загрузить заметки
  {sep}
  {q}  Выход
  {sep}
"""


def build_main_menu(count: int) -> str:
    return MAIN_MENU.format(
        bold_title=bold(f"NOTEBOOK ORGANIZER  ({count} заметок)"),
        sep=dim(SEPARATOR),
        n1=bold(" 1."),
        n2=bold(" 2."),
        n3=bold(" 3."),
        n4=bold(" 4."),
        n5=bold(" 5."),
        f1=bold(" 6."),
        f2=bold(" 7."),
        f3=bold(" 8."),
        f4=bold(" 9."),
        u1=bold("10."),
        u2=bold("11."),
        s1=bold("12."),
        s2=bold("13."),
        q=bold(" 0."),
    )


# ---------------------------------------------------------------------------
# Класс CLI-приложения
# ---------------------------------------------------------------------------

class NotebookCLI:
    """Консольное приложение Notebook Organizer."""

    def __init__(self, manager: NoteManager | None = None) -> None:
        self._manager = manager or NoteManager()
        self._running = False

    # ------------------------------------------------------------------
    # Запуск
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Запускает главный цикл приложения."""
        self._running = True
        self._auto_load()
        while self._running:
            try:
                self._show_main_menu()
            except KeyboardInterrupt:
                print()
                if confirm("Выйти из приложения?"):
                    self._exit()

    def _auto_load(self) -> None:
        """Автоматически загружает заметки при запуске."""
        try:
            count = self._manager.load()
            if count:
                print_success(f"Загружено {count} заметок из {self._manager.storage_path}")
        except StorageError:
            pass  # Файл ещё не создан — это нормально

    # ------------------------------------------------------------------
    # Главное меню
    # ------------------------------------------------------------------

    def _show_main_menu(self) -> None:
        os.system("clear" if os.name == "posix" else "cls")
        print(build_main_menu(self._manager.count()))
        choice = ask("Выберите действие")
        actions: dict[str, Callable] = {
            "1": self._list_notes,
            "2": self._create_note,
            "3": self._view_note,
            "4": self._edit_note,
            "5": self._delete_note,
            "6": self._filter_by_tag,
            "7": self._filter_by_date,
            "8": self._filter_by_type,
            "9": self._search_by_title,
            "10": self._undo,
            "11": self._show_history,
            "12": self._save,
            "13": self._load,
            "0": self._exit,
        }
        action = actions.get(choice)
        if action:
            action()
        else:
            print_warning("Неизвестная команда. Введите номер из меню.")
            self._pause()

    def _pause(self) -> None:
        ask("Нажмите Enter для продолжения")

    # ------------------------------------------------------------------
    # 1. Список заметок
    # ------------------------------------------------------------------

    def _list_notes(self) -> None:
        print_header("Список заметок")
        notes = self._manager.sorted_by_date()
        if not notes:
            print_warning("Заметок нет. Создайте первую заметку.")
        else:
            items = [format_note_short(n, i + 1) + "\n" for i, n in enumerate(notes)]
            paginate(items)
        self._pause()

    # ------------------------------------------------------------------
    # 2. Создание заметки
    # ------------------------------------------------------------------

    def _create_note(self) -> None:
        print_header("Создание заметки")
        print_info("Выберите тип заметки:")
        print_info(f"  {bold('1.')} Текстовая заметка")
        print_info(f"  {bold('2.')} Голосовая заметка")
        print_info(f"  {bold('3.')} Чеклист")
        note_type = ask("Тип", "1")
        if note_type == "1":
            self._create_text_note()
        elif note_type == "2":
            self._create_voice_note()
        elif note_type == "3":
            self._create_checklist_note()
        else:
            print_error("Неверный тип. Выберите 1, 2 или 3.")
            self._pause()

    def _create_text_note(self) -> None:
        print_header("Новая текстовая заметка")
        title = ask("Заголовок")
        if not title:
            print_error("Заголовок не может быть пустым.")
            self._pause()
            return
        text = ask_multiline("Текст заметки")
        tags = ask_tags()
        try:
            note = self._manager.create_text_note(title=title, text=text, tags=tags)
            print_success(f"Заметка «{note.title}» создана (ID: {note.note_id[:8]}…)")
            self._offer_save()
        except (ValueError, TypeError) as e:
            print_error(str(e))
        self._pause()

    def _create_voice_note(self) -> None:
        print_header("Новая голосовая заметка")
        title = ask("Заголовок")
        if not title:
            print_error("Заголовок не может быть пустым.")
            self._pause()
            return
        transcription = ask_multiline("Транскрипция")
        duration_raw = ask("Длительность (секунды)", "0")
        tags = ask_tags()
        try:
            duration = int(duration_raw)
            note = self._manager.create_voice_note(
                title=title,
                transcription=transcription,
                duration_sec=duration,
                tags=tags,
            )
            print_success(f"Голосовая заметка «{note.title}» создана (ID: {note.note_id[:8]}…)")
            self._offer_save()
        except (ValueError, TypeError) as e:
            print_error(str(e))
        self._pause()

    def _create_checklist_note(self) -> None:
        print_header("Новый чеклист")
        title = ask("Заголовок")
        if not title:
            print_error("Заголовок не может быть пустым.")
            self._pause()
            return
        tags = ask_tags()
        items: list[dict] = []
        print_info("Введите пункты чеклиста (пустая строка — завершить):")
        while True:
            item_text = ask(f"Пункт {len(items) + 1}")
            if not item_text:
                break
            items.append({"text": item_text, "done": False})
        try:
            note = self._manager.create_checklist_note(
                title=title, items=items, tags=tags
            )
            print_success(f"Чеклист «{note.title}» создан ({len(items)} пунктов)")
            self._offer_save()
        except (ValueError, TypeError) as e:
            print_error(str(e))
        self._pause()

    # ------------------------------------------------------------------
    # 3. Просмотр заметки
    # ------------------------------------------------------------------

    def _view_note(self) -> None:
        print_header("Просмотр заметки")
        note_id = self._ask_note_id()
        if not note_id:
            return
        try:
            note = self._manager.get_by_id(note_id)
            print()
            print(format_note_full(note))
        except NoteNotFoundError as e:
            print_error(str(e))
        self._pause()

    # ------------------------------------------------------------------
    # 4. Редактирование заметки
    # ------------------------------------------------------------------

    def _edit_note(self) -> None:
        print_header("Редактирование заметки")
        note_id = self._ask_note_id()
        if not note_id:
            return
        try:
            note = self._manager.get_by_id(note_id)
        except NoteNotFoundError as e:
            print_error(str(e))
            self._pause()
            return

        print()
        print(format_note_full(note))
        print_separator()
        print_info("Оставьте поле пустым, чтобы не изменять значение.")
        print()

        kwargs: dict = {}

        new_title = ask(f"Новый заголовок", note.title)
        if new_title and new_title != note.title:
            kwargs["title"] = new_title

        new_tags_raw = ask(
            "Новые теги (через запятую)",
            ", ".join(note.tags) if note.tags else "",
        )
        if new_tags_raw is not None:
            new_tags = [t.strip() for t in new_tags_raw.split(",") if t.strip()]
            if new_tags != note.tags:
                kwargs["tags"] = new_tags

        if isinstance(note, TextNote):
            print_info(f"Текущий текст: {note.preview()}")
            if confirm("Редактировать текст?"):
                kwargs["text"] = ask_multiline("Новый текст")

        elif isinstance(note, VoiceNote):
            print_info(f"Текущая транскрипция: {note.preview()}")
            if confirm("Редактировать транскрипцию?"):
                kwargs["transcription"] = ask_multiline("Новая транскрипция")
            new_dur = ask(f"Длительность (сек)", str(note.duration_sec))
            try:
                new_dur_int = int(new_dur)
                if new_dur_int != note.duration_sec:
                    kwargs["duration_sec"] = new_dur_int
            except ValueError:
                print_warning("Некорректное значение длительности, оставлено прежнее.")

        elif isinstance(note, ChecklistNote):
            print_info("Управление пунктами чеклиста:")
            print_info(f"  {bold('a.')} Добавить пункт")
            print_info(f"  {bold('t.')} Переключить статус пункта")
            print_info(f"  {bold('d.')} Удалить пункт")
            print_info(f"  {bold('s.')} Пропустить")
            action = ask("Действие", "s").lower()
            if action == "a":
                item_text = ask("Текст нового пункта")
                if item_text:
                    new_items = note.items + [{"text": item_text, "done": False}]
                    kwargs["items"] = new_items
            elif action == "t":
                for i, item in enumerate(note.items):
                    mark = "✓" if item["done"] else "○"
                    print_info(f"  {i + 1}. [{mark}] {item['text']}")
                idx_raw = ask("Номер пункта для переключения")
                try:
                    idx = int(idx_raw) - 1
                    new_items = list(note.items)
                    new_items[idx]["done"] = not new_items[idx]["done"]
                    kwargs["items"] = new_items
                except (ValueError, IndexError):
                    print_error("Неверный номер пункта.")
            elif action == "d":
                for i, item in enumerate(note.items):
                    print_info(f"  {i + 1}. {item['text']}")
                idx_raw = ask("Номер пункта для удаления")
                try:
                    idx = int(idx_raw) - 1
                    new_items = [item for i, item in enumerate(note.items) if i != idx]
                    kwargs["items"] = new_items
                except (ValueError, IndexError):
                    print_error("Неверный номер пункта.")

        if not kwargs:
            print_warning("Изменений не внесено.")
            self._pause()
            return

        try:
            updated = self._manager.update_note(note.note_id, **kwargs)
            print_success(f"Заметка «{updated.title}» обновлена.")
            self._offer_save()
        except (ValueError, TypeError, NoteNotFoundError) as e:
            print_error(str(e))
        self._pause()

    # ------------------------------------------------------------------
    # 5. Удаление заметки
    # ------------------------------------------------------------------

    def _delete_note(self) -> None:
        print_header("Удаление заметки")
        note_id = self._ask_note_id()
        if not note_id:
            return
        try:
            note = self._manager.get_by_id(note_id)
            print()
            print(format_note_short(note))
            print()
            if confirm(f"Удалить заметку «{note.title}»?"):
                self._manager.delete_note(note.note_id)
                print_success(f"Заметка «{note.title}» удалена.")
                self._offer_save()
            else:
                print_warning("Удаление отменено.")
        except NoteNotFoundError as e:
            print_error(str(e))
        self._pause()

    # ------------------------------------------------------------------
    # 6–9. Фильтрация и поиск
    # ------------------------------------------------------------------

    def _filter_by_tag(self) -> None:
        print_header("Фильтр по тегу")
        tag = ask("Введите тег")
        if not tag:
            self._pause()
            return
        results = self._manager.filter_by_tag(tag)
        self._show_filter_results(results, f"тег #{tag}")

    def _filter_by_date(self) -> None:
        print_header("Фильтр по дате")
        print_info("Форматы: ГГГГ-ММ-ДД  или  ГГГГ-ММ-ДД ЧЧ:ММ:СС")
        date_str = ask("Дата (или начало диапазона)")
        if not date_str:
            self._pause()
            return
        end_str = ask("Конец диапазона (Enter — только эта дата)")

        try:
            if " " in date_str or ":" in date_str:
                start_dt = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
            else:
                start_dt = datetime.strptime(date_str, "%Y-%m-%d")

            if end_str:
                if " " in end_str or ":" in end_str:
                    end_dt = datetime.strptime(end_str, "%Y-%m-%d %H:%M:%S")
                else:
                    end_dt = datetime.strptime(end_str + " 23:59:59", "%Y-%m-%d %H:%M:%S")
                results = self._manager.filter_by_date_range(start_dt, end_dt)
                label = f"{date_str} — {end_str}"
            else:
                results = self._manager.filter_by_date(start_dt.date())
                label = date_str
        except ValueError as e:
            print_error(f"Неверный формат даты: {e}")
            self._pause()
            return

        self._show_filter_results(results, f"дата {label}")

    def _filter_by_type(self) -> None:
        print_header("Фильтр по типу")
        print_info(f"  {bold('1.')} Текстовые заметки")
        print_info(f"  {bold('2.')} Голосовые заметки")
        print_info(f"  {bold('3.')} Чеклисты")
        choice = ask("Тип", "1")
        type_map = {"1": "text", "2": "voice", "3": "checklist"}
        note_type = type_map.get(choice)
        if not note_type:
            print_error("Неверный выбор.")
            self._pause()
            return
        results = self._manager.filter_by_type(note_type)
        self._show_filter_results(results, f"тип «{TYPE_LABELS[note_type]}»")

    def _search_by_title(self) -> None:
        print_header("Поиск по заголовку")
        query = ask("Строка поиска")
        if not query:
            self._pause()
            return
        results = self._manager.search_by_title(query)
        self._show_filter_results(results, f"«{query}» в заголовке")

    def _show_filter_results(self, results: list[Note], label: str) -> None:
        print()
        if not results:
            print_warning(f"По запросу ({label}) ничего не найдено.")
        else:
            print_info(f"Найдено {len(results)} заметок ({label}):")
            print()
            items = [format_note_short(n, i + 1) + "\n" for i, n in enumerate(results)]
            paginate(items)
        self._pause()

    # ------------------------------------------------------------------
    # 10–11. Отмена и история
    # ------------------------------------------------------------------

    def _undo(self) -> None:
        print_header("Отмена действия")
        if not self._manager.can_undo:
            print_warning("История действий пуста — нечего отменять.")
            self._pause()
            return
        try:
            description = self._manager.undo()
            print_success(f"Отменено: {description}")
            self._offer_save()
        except IndexError as e:
            print_error(str(e))
        self._pause()

    def _show_history(self) -> None:
        print_header("История действий")
        history = self._manager.undo_history()
        if not history:
            print_warning("История пуста.")
        else:
            for i, desc in enumerate(reversed(history), 1):
                print_info(f"  {dim(str(i) + '.')} {desc}")
        self._pause()

    # ------------------------------------------------------------------
    # 12–13. Сохранение и загрузка
    # ------------------------------------------------------------------

    def _save(self) -> None:
        print_header("Сохранение заметок")
        try:
            self._manager.save()
            print_success(
                f"Сохранено {self._manager.count()} заметок → {self._manager.storage_path}"
            )
        except StorageError as e:
            print_error(str(e))
        self._pause()

    def _load(self) -> None:
        print_header("Загрузка заметок")
        if self._manager.count() > 0:
            if not confirm("Текущие заметки будут заменены. Продолжить?"):
                print_warning("Загрузка отменена.")
                self._pause()
                return
        try:
            count = self._manager.load()
            print_success(f"Загружено {count} заметок из {self._manager.storage_path}")
        except StorageError as e:
            print_error(str(e))
        self._pause()

    def _offer_save(self) -> None:
        """Предлагает сохранить заметки после изменений."""
        if confirm("Сохранить изменения?"):
            try:
                self._manager.save()
                print_success("Сохранено.")
            except StorageError as e:
                print_error(str(e))

    # ------------------------------------------------------------------
    # 0. Выход
    # ------------------------------------------------------------------

    def _exit(self) -> None:
        print_header("Выход")
        if self._manager.count() > 0:
            if confirm("Сохранить заметки перед выходом?"):
                try:
                    self._manager.save()
                    print_success(f"Сохранено → {self._manager.storage_path}")
                except StorageError as e:
                    print_error(str(e))
        print_info("До свидания!")
        print()
        self._running = False

    # ------------------------------------------------------------------
    # Вспомогательные методы
    # ------------------------------------------------------------------

    def _ask_note_id(self) -> str | None:
        """Запрашивает ID заметки (полный или сокращённый)."""
        notes = self._manager.get_all()
        if not notes:
            print_warning("Заметок нет.")
            self._pause()
            return None

        print_info("Введите ID заметки (или первые символы) или номер из списка:")
        print()
        for i, n in enumerate(notes, 1):
            type_label = TYPE_LABELS.get(n.note_type, n.note_type)
            print_info(f"  {i:>3}. {bold(n.title)}  {dim(n.note_id[:8] + '…')}  [{type_label}]")
        print()

        raw = ask("ID или номер")
        if not raw:
            return None

        # Попытка по номеру
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(notes):
                return notes[idx].note_id
        except ValueError:
            pass

        # Попытка по префиксу ID
        matches = [n for n in notes if n.note_id.startswith(raw)]
        if len(matches) == 1:
            return matches[0].note_id
        elif len(matches) > 1:
            print_error(f"Найдено несколько заметок с префиксом '{raw}'. Уточните ID.")
            return None

        print_error(f"Заметка с ID '{raw}' не найдена.")
        return None
