"""Тесты для Notebook Organizer."""
